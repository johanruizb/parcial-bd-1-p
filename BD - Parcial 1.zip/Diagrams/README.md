Diagramas realizados con el apoyo de Draw.io.
Diagramas de entidad-relacion y diagramas relacionales.

Archivo que contiene los diagramas en Draw.io:
[Google Drive - Entidad relacion](https://drive.google.com/file/d/1GBMnwRRS3kzPR1pxE49HQn6-2wQCwhZg/view?usp=sharing)

---
Enlaces de interes:

[Draw.io](https://app.diagrams.net/)
