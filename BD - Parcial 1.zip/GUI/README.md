Para el desarrollo de la GUI se usó React, react-bootstrap y bootstrap. Para las peticiones se uso Bent.
Aqui esta contenido el codigo fuente de la GUI.


Muestra desplegada de la GUI: [Attendace](https://una-web.000webhostapp.com/)

---
Enlaces de interes:

[React-Bootstrap](https://react-bootstrap.github.io/)

[Bootstrap](https://getbootstrap.com/)

[ReactJS](https://es.reactjs.org/)

---

- ReactJS es el marco de JavaScript front-end más popular. Los desarrolladores utilizan JSX, una combinación de HTML y JavaScript, para crear vistas de forma natural. Los desarrolladores también pueden crear componentes para bloques que se pueden reutilizar en sus aplicaciones.


- Bent es un cliente HTTP funcional para Node.js y navegadores con async/await. Versión de navegador increíblemente pequeña basada en fetch sin dependencias externas ni polyfills.

