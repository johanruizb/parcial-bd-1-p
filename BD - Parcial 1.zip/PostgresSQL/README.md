Para el desarrollo e implementación de la base de datos,
se usó postgres, más específicamente un docker de postgres 
con Docker Desktop. El archivo SQL contiene la información 
de las tablas que se extrajo del diseño hecho con Draw.io:

[attendace.sql](https://github.com/johanruizb/parcial-bd-1-p/blob/master/PostgresSQL/attendace.sql)

---
- PostgreSQL 
Es una base de datos avanzada de código 
abierto, totalmente gratuita, que cumple bien
con estándares SQL y su rendimiento es comparable 
con otros SGBD de uso comercial, este potente sistema 
de base de datos relacional con más de 30 años de 
desarrollo activo ha ganado una sólida reputación. 
