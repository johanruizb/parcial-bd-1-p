Para el desarrollo del servidor se usó la app generada por Express-Generator 
en Visual Studio Code, la app de servidor contiene las rutas y respuestas a las peticiones.

Aqui se observa todo el codigo fuente del servidor.

---

Enlaces de interes: 

[Node.js](https://nodejs.org/es/)

[Express](https://expressjs.com/es/)
